See the demo by opening the Globe.html file in a flash enabled-browser.
Make sure your browser's flash plugin is updated.

======== Earth3D =========



3D Globe in Flash with clickable regions.


Click on a region to highlight/center that region.
Double-click to open URL.



To customize the URLs/selection masks, modify the settings.xml file under the "assets" directory.
 The format of the file is pretty self-explanatory.